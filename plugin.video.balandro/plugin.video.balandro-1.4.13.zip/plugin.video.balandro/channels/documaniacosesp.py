# -*- coding: utf-8 -*-

from platformcode import logger
from core.item import Item
from core import httptools, scrapertools, servertools


host = "https://documaniacosesp.com/"


def mainlist(item):
    logger.info()
    itemlist = []
    
    itemlist.append(item.clone( title='Últimos documentales', action='list_all', url=host ))

    itemlist.append(item.clone( title = 'Buscar documental ...', action = 'search', search_type = 'documentary' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    patron = '<div class="post-wrapper">(.*?)</header>'

    matches = scrapertools.find_multiple_matches(data, patron)

    for match in matches:
        url = scrapertools.find_single_match(match, '<h2 class="entry-title"><a href=.*?<a href="([^"]+)"')

        if url:
            title = scrapertools.find_single_match(match, 'rel="bookmark">(.*?)</a>')

            title = scrapertools.slugify(title)

            title = title.replace('-8211-', ' ').replace('-', ' ')

            title = title.replace('documentales', '').replace('documental', '').replace('videodocumental', '')
            title = title.replace('documentaries', '').replace('documentary', '')
            title = title.replace('online', '').replace('video', '')
            title = title.replace('completos', '').replace('completo', '')

            title = title.strip()
            title = title.lower()
            title = title.capitalize()

            thumb = scrapertools.find_single_match(match, 'style="background-image: url(.*?)">')
            thumb = thumb.replace('(', '').replace(')', '').replace("'", '').replace('"', '')
 
            itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, contentType='movie', contentTitle=title, contentExtra='documentary' ))

    next_page_link = scrapertools.find_single_match(data, '<nav class="navigation pagination".*?<a class="next page-numbers" href="([^"]+)')
    if next_page_link != '':
        itemlist.append(item.clone( title='>> Página siguiente', action='list_all', url = next_page_link ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    url = scrapertools.find_single_match(data, '<div class="entry-content single-entry-content">.*?<a href="([^"]+)')
    if url:
        servidor = servertools.get_server_from_url(url)
        if servidor and servidor != 'directo':
            itemlist.append(Item( channel = item.channel, action = 'play', server=servidor, title = servidor.capitalize(), url = url, language = 'Esp' ))
    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + '?s=' + texto.replace(" ", "+")
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
